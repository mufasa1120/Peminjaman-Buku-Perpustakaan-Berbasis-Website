document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById('borrowForm');
    
    if (form) {
        form.addEventListener('submit', function (event) {
            // Ambil nilai dari input
            const nama = document.getElementById('nama').value.trim();
            const keperluan = document.getElementById('keperluan').value.trim();

            // Validasi input
            if (nama === '') {
                alert('Silakan masukkan Nama tamu.');
                event.preventDefault(); // Hentikan pengiriman form jika ada error
                return;
            }

            if (keperluan === '') {
                alert('Silakan masukkan Keperluan peminjaman buku.');
                event.preventDefault(); // Hentikan pengiriman form jika ada error
                return;
            }

            // Jika validasi sukses, lanjutkan pengiriman form
        });
    } else {
        console.error("Form dengan ID 'borrowForm' tidak ditemukan.");
    }

    const searchInput = document.getElementById('bookSearch');
    const resultsContainer = document.getElementById('bookResults');
    const selectedBookId = document.getElementById('selectedBookId');

    searchInput.addEventListener('input', function () {
        const query = this.value.trim();
        if (query.length < 2) {
            resultsContainer.innerHTML = '';
            return;
        }

        // Fetch dari endpoint pencarian buku
        fetch(`search-book.php?term=${encodeURIComponent(query)}`)
            .then(response => response.json())
            .then(data => {
                resultsContainer.innerHTML = '';
                if (data.length === 0) {
                    resultsContainer.innerHTML = '<div class="list-group-item">Tidak ditemukan</div>';
                    return;
                }

                data.forEach(book => {
                    const item = document.createElement('div');
                    item.className = 'list-group-item list-group-item-action';
                    item.textContent = `${book.judul} - ${book.penulis}`;
                    item.style.cursor = 'pointer';
                    item.addEventListener('click', () => {
                        searchInput.value = `${book.judul} - ${book.penulis}`;
                        selectedBookId.value = book.id_buku;
                        resultsContainer.innerHTML = '';
                    });
                    resultsContainer.appendChild(item);
                });
            });
    });

    // Tutup hasil pencarian jika klik di luar
    document.addEventListener('click', function (e) {
        if (!resultsContainer.contains(e.target) && e.target !== searchInput) {
            resultsContainer.innerHTML = '';
        }
    });
});