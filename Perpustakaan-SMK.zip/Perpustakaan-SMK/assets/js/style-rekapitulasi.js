// Handle user table switching
document.querySelectorAll('.tab-item').forEach(function (tab) {
    tab.addEventListener('click', function () {
        document.querySelectorAll('.tab-item').forEach(function (t) {
            t.classList.remove('active');
        });
        this.classList.add('active');

        // Simulate loading different tables
        const role = this.textContent.toLowerCase();
        if (role === 'siswa') {
            // Load siswa table
            document.querySelector('#rekapTableContainer tbody').innerHTML = `
                <tr>
                    <td>Deva Permata Santoso</td>
                    <td>X IPA 2</td>
                    <td>Siswa</td>
                    <td>Membaca Buku Bla Bla</td>
                    <td>01-12-2004</td>
                </tr>
                <!-- Add more rows as needed -->
            `;
        } else if (role === 'staff-guru') {
            // Load staff/guru table
            document.querySelector('#rekapTableContainer tbody').innerHTML = `
                <tr>
                    <td>Dr. Joko Widodo</td>
                    <td>-</td>
                    <td>Guru</td>
                    <td>Membaca Buku Bla Bla</td>
                    <td>01-12-2004</td>
                </tr>
                <!-- Add more rows as needed -->
            `;
        } else if (role === 'tamu') {
            // Load tamu table
            document.querySelector('#rekapTableContainer tbody').innerHTML = `
                <tr>
                    <td>John Doe</td>
                    <td>-</td>
                    <td>Tamu</td>
                    <td>Membaca Buku Bla Bla</td>
                    <td>01-12-2004</td>
                </tr>
                <!-- Add more rows as needed -->
            `;
        }
    });
});