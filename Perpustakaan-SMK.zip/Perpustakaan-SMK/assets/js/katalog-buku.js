document.addEventListener('DOMContentLoaded', function() {
    // Fungsi untuk animasi scroll halus
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Fungsi untuk filter buku
    const filterBuku = (kategori) => {
        console.log(`Filter buku berdasarkan: ${kategori}`);
        // Di sini Anda bisa menambahkan logika untuk memfilter buku
        // Misalnya dengan AJAX untuk mengambil data dari server
    };

    // Event listener untuk tombol filter (jika ada)
    const filterButtons = document.querySelectorAll('.filter-button');
    if (filterButtons) {
        filterButtons.forEach(button => {
            button.addEventListener('click', function() {
                const kategori = this.getAttribute('data-kategori');
                filterBuku(kategori);
            });
        });
    }

    // Animasi untuk item buku
    const bukuItems = document.querySelectorAll('.buku-group');
    bukuItems.forEach((item, index) => {
        // Delay animasi untuk efek berurutan
        item.style.transitionDelay = `${index * 0.05}s`;
    });

    // Fungsi untuk menampilkan total buku
    function updateTotalBuku() {
        const totalBukuElement = document.querySelector('.total-buku');
        if (totalBukuElement) {
            // Hitung total buku dari semua item
            const semuaBuku = document.querySelectorAll('.buku-group');
            totalBukuElement.textContent = `Total Buku : ${semuaBuku.length}`;
        }
    }

    // Panggil fungsi update total buku saat halaman dimuat
    updateTotalBuku();

    // Simulasi pencarian (jika ada search box)
    const searchBox = document.getElementById('search-box');
    if (searchBox) {
        searchBox.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const semuaBuku = document.querySelectorAll('.buku-group');
            
            semuaBuku.forEach(buku => {
                const judul = buku.querySelector('h4').textContent.toLowerCase();
                if (judul.includes(searchTerm)) {
                    buku.style.display = 'flex';
                } else {
                    buku.style.display = 'none';
                }
            });
            
            updateTotalBuku();
        });
    }
});