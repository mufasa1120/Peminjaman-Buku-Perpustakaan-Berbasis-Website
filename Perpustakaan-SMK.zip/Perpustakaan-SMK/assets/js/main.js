// Handle form submission
document.getElementById('loginForm').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent default form submission

    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();

    const notification = document.getElementById('notification');
    notification.textContent = ''; // Clear previous message

    // Kirim data ke server
    fetch('login-check.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.location.href = data.redirect;
        } else {
            notification.textContent = data.message || 'Username atau Password salah!';
        }
    })
    .catch(error => {
        console.error('Error:', error);
        notification.textContent = 'Terjadi kesalahan pada koneksi.';
    });
});