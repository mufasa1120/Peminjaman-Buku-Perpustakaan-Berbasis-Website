// Fungsi untuk load data dari database
async function loadUserData(role) {
    showLoading();
    try {
        const response = await fetch(`api.php?action=getUsers&role=${role}`);
        filteredData = await response.json();
        renderUserTable(filteredData);
    } catch (error) {
        console.error('Error:', error);
    } finally {
        hideLoading();
    }
}

// Fungsi untuk tambah user
async function submitForm() {
    const formData = {
        nama: document.getElementById('username').value,
        nisn: document.getElementById('nuptk').value,
        kelas: document.getElementById('kelas').value || '-',
        password: document.getElementById('password').value,
        role: document.getElementById('role').value
    };

    try {
        const response = await fetch('api.php?action=addUser', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });

        const result = await response.json();
        if (result.success) {
            showAlert('success', 'Akun berhasil ditambahkan!');
            loadUserData(currentRole); // Reload data
        }
    } catch (error) {
        showAlert('error', 'Terjadi kesalahan server');
    }
}

// Fungsi untuk hapus user
async function deleteUser(id) {
    if (!confirm('Apakah Anda yakin?')) return;
    
    try {
        await fetch(`api.php?action=deleteUser&id=${id}`, { method: 'DELETE' });
        loadUserData(currentRole); // Reload data
    } catch (error) {
        console.error('Error:', error);
    }
}